package com.riwi.logistic.api.controllers;


import com.riwi.logistic.domain.service.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class AuditController {

    @Autowired
    private PdfService pdfService;

    @GetMapping("/api/v1/audit-report")
    public ResponseEntity<byte[]> getAuditReport(@RequestParam String date) {
        try {
            String reportData = "Audit report for date: " + date;
            byte[] pdfBytes = pdfService.generateAuditReport(reportData);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", "audit-report.pdf");
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
