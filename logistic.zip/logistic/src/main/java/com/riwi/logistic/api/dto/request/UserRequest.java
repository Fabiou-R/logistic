package com.riwi.logistic.api.dto.request;

import com.riwi.logistic.domain.model.enums.UserRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRequest {

    private Long id;
    private String username;
    private String email;
    private String password;
    private UserRole role;
}