package com.riwi.logistic.api.dto.response;

import com.riwi.logistic.api.dto.response.LoadResponse;  // Importar LoadResponse
import com.riwi.logistic.domain.model.enums.StatusPallets;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PalletResponse {
    private Double weightMax;
    private Double heightMax;
    private String ubication;
    private LoadResponse load;
    private StatusPallets status;
}
