package com.riwi.logistic.api.dto.response;

import com.riwi.logistic.domain.model.enums.UserRole;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private String username;
    private String email;
    private UserRole role;
}