package com.riwi.logistic.domain.service;


import com.riwi.logistic.api.dto.request.LoadRequest;
import com.riwi.logistic.api.utils.TransformUtil;
import com.riwi.logistic.domain.model.LoadEntity;
import com.riwi.logistic.domain.repository.LoadRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class LoadService {
    @Autowired
    private LoadRepository loadRepo;

    @Autowired
    private TransformUtil transformUtil;

    public LoadEntity create(LoadRequest loadRequest) {
        LoadEntity load = new LoadEntity();
        load.setWeight(loadRequest.getWeight());
        load.setStatus(loadRequest.getStatus());


        return loadRepo.save(load);
    }

    public List<LoadEntity> readAll() {
        return loadRepo.findAll();
    }

    public LoadEntity readById(Long id) {
        return loadRepo.findById(id).orElse(null);
    }

    public LoadEntity update(Long id, LoadRequest loadRequest) {
        LoadEntity load = readById(id);
        if (load != null) {
            load.setStatus(loadRequest.getStatus());
            load.setWeight(loadRequest.getWeight());
            return loadRepo.save(load);
        }else {
            throw new RuntimeException("load not fund.");
        }
    }

    public void delete(Long id) {
        loadRepo.deleteById(id);
    }
}
