package com.riwi.logistic.api.utils;

import com.riwi.logistic.api.dto.request.LoadRequest;
import com.riwi.logistic.api.dto.request.PalletRequest;
import com.riwi.logistic.api.dto.request.UserRequest;
import com.riwi.logistic.api.dto.response.LoadResponse;
import com.riwi.logistic.api.dto.response.PalletResponse;
import com.riwi.logistic.api.dto.response.UserResponse;
import com.riwi.logistic.domain.model.LoadEntity;
import com.riwi.logistic.domain.model.PalletEntity;
import com.riwi.logistic.domain.model.UserEntity;
import com.riwi.logistic.domain.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TransformUtil {

    @Autowired
    private UserService userService;

    // Utilidades para transformar Usuarios
    // de UserRequest a userEntity
    public UserEntity transformUserEntity(UserRequest userReq){
        return UserEntity.builder()
                .id(userReq.getId())
                .username(userReq.getUsername())
                .email(userReq.getEmail())
                .password(userReq.getPassword())
                .role(userReq.getRole())
                .build();
    }

    // de UserEntity a userResponse
    public UserResponse transformUserRes(UserEntity userEntity){
        return UserResponse.builder()
                .email(userEntity.getEmail())
                .username(userEntity.getUsername())
                .role(userEntity.getRole())
                .build();
    }

    public LoadEntity transformLoadEntity(LoadRequest loadReq){
        return LoadEntity.builder()
                .id(loadReq.getId())
                .weight(loadReq.getWeight())
                .status(loadReq.getStatus())
                .build();
    }

    public LoadResponse transformLoadRes(LoadEntity loadEntity){
        return LoadResponse.builder()
                .weight(loadEntity.getWeight())
                .status(loadEntity.getStatus())
                .build();
    }
    public PalletEntity transformPalletEntity(PalletRequest palletReq){
        return PalletEntity.builder()
                .id(palletReq.getId())
                .weightMax(palletReq.getWeightMax())
                .heightMax(palletReq.getHeightMax())
                .load(palletReq.getLoad())
                .status(palletReq.getStatus())
                .ubication(palletReq.getUbication())
                .build();
    }

    public PalletResponse transformPelletRes(PalletEntity palletEntity) {
        return PalletResponse.builder()
                .heightMax(palletEntity.getHeightMax())
                .load(palletEntity.getLoad() != null ? transformLoadRes(palletEntity.getLoad()) : null)
                .status(palletEntity.getStatus())
                .ubication(palletEntity.getUbication())
                .weightMax(palletEntity.getWeightMax())
                .build();
    }

}
