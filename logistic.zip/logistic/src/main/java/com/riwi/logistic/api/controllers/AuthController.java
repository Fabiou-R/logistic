package com.riwi.logistic.api.controllers;

import com.riwi.logistic.api.dto.request.UserRequest;
import com.riwi.logistic.api.dto.response.UserResponse;
import com.riwi.logistic.domain.model.UserEntity;
import com.riwi.logistic.domain.model.enums.UserRole;
import com.riwi.logistic.domain.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final UserService userService;

    @Autowired
    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    @Operation(description = "Login endpoint")
    @ApiResponse(responseCode = "200", description = "User logged in successfully")
    @ApiResponse(responseCode = "400", description = "Unable to log in user")
    public ResponseEntity<String> login(
            @RequestParam String username,
            @RequestParam String password) {

        UserEntity user = userService.getUserByUsername(username);

        if (user == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Usuario no encontrado: " + username);
        }

        // Verificar la contraseña utilizando el método verify
        try {
            String token = userService.verify(username, password);
            return ResponseEntity.ok(token);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/register")
    @Operation(description = "Public Register endpoint")
    @ApiResponse(responseCode = "201", description = "User created successfully")
    @ApiResponse(responseCode = "400", description = "Unable to create user")
    public ResponseEntity<UserResponse> createUser(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String email) {

        // Verificar si el usuario ya existe
        if (userService.getUserByUsername(username) != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        UserRequest userRequest = new UserRequest();
        userRequest.setUsername(username);
        userRequest.setPassword(password);
        userRequest.setEmail(email);
        userRequest.setRole(UserRole.USER);

        // Guardar el nuevo usuario
        UserResponse savedUser = userService.saveUser(userRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
    }
}
