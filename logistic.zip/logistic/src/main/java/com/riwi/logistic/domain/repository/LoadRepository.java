package com.riwi.logistic.domain.repository;

import com.riwi.logistic.domain.model.LoadEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoadRepository extends JpaRepository<LoadEntity,Long> {
}
