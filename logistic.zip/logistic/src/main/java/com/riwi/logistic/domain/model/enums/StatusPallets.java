package com.riwi.logistic.domain.model.enums;

public enum StatusPallets {
    AVAILABLE,
    IN_USE,
    DAMAGED
}
