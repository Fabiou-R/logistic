package com.riwi.logistic.api.dto.request;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserPublicRequest {
    public String username;
    public String password;
    public String email;
}