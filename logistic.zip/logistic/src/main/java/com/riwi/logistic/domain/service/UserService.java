package com.riwi.logistic.domain.service;

import com.riwi.logistic.api.dto.request.UserPublicRequest;
import com.riwi.logistic.api.dto.request.UserRequest;
import com.riwi.logistic.api.dto.response.UserResponse;
import com.riwi.logistic.api.utils.TransformUtil;
import com.riwi.logistic.domain.model.UserEntity;
import com.riwi.logistic.domain.repository.UserRepository;
import com.riwi.logistic.infrastructure.security.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private TransformUtil transformUtil;

    // Password encoder for better security
    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    public UserResponse saveUser(UserRequest user) {
        if (userRepo.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        user.setPassword(encoder.encode(user.getPassword()));
        UserEntity newUser = transformUtil.transformUserEntity(user);
        UserEntity savedUser = userRepo.save(newUser);
        return transformUtil.transformUserRes(savedUser);
    }

    public List<UserEntity> getAllUsers() {
        return userRepo.findAll();
    }

    public UserResponse getUserById(Long id) {
        return transformUtil.transformUserRes(
                userRepo.findById(id)
                        .orElseThrow(() -> new RuntimeException("User not found"))
        );
    }

    public void deleteUserById(Long id) {
        userRepo.findById(id).ifPresentOrElse(userRepo::delete, () -> {
            throw new RuntimeException("User not found");
        });
    }

    public String verify(String username, String rawPassword) {
        try {
            // Autenticar al usuario
            Authentication authentication = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, rawPassword));
            if (authentication.isAuthenticated()) {
                UserEntity user = getUserByUsername(username); // Obtenemos el usuario
                return jwtService.generateToken(user.getUsername(), user.getRole().toString());
            } else {
                throw new RuntimeException("Authentication failed");
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to authenticate user: " + e.getMessage());
        }
    }

    public UserEntity getUserByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    public UserResponse updateUser(Long id, UserPublicRequest userRequest) {
        UserEntity updatedUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        updatedUser.setUsername(userRequest.getUsername());
        if (userRequest.getPassword() != null && !userRequest.getPassword().isEmpty()) {
            updatedUser.setPassword(encoder.encode(userRequest.getPassword()));
        }
        updatedUser.setEmail(userRequest.getEmail());
        userRepo.save(updatedUser);
        return transformUtil.transformUserRes(updatedUser);
    }
}
