package com.riwi.logistic.api.dto.response;

import com.riwi.logistic.domain.model.enums.StatusLoad;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoadResponse {
    private Long id;
    private Double weight;
    private StatusLoad status;
}
