package com.riwi.logistic.domain.repository;

import com.riwi.logistic.domain.model.PalletEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PalletRepository extends JpaRepository<PalletEntity,Long> {
}
