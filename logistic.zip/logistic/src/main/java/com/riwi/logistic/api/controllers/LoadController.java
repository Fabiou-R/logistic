package com.riwi.logistic.api.controllers;

import com.riwi.logistic.api.dto.request.LoadRequest;
import com.riwi.logistic.api.dto.response.LoadResponse;
import com.riwi.logistic.domain.model.LoadEntity;
import com.riwi.logistic.domain.service.LoadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/loads")
public class LoadController {

    private final LoadService loadService;

    @Autowired
    public LoadController(LoadService loadService) {
        this.loadService = loadService;
    }

    @PostMapping
    @Operation(description = "Create a new load")
    @ApiResponse(responseCode = "201", description = "Load created successfully")
    @ApiResponse(responseCode = "400", description = "Unable to create load")
    public ResponseEntity<LoadResponse> createLoad(@RequestBody LoadRequest loadRequest) {
        LoadEntity savedLoad = loadService.create(loadRequest);
        LoadResponse loadResponse = LoadResponse.builder()
                .id(savedLoad.getId())
                .weight(savedLoad.getWeight())
                .status(savedLoad.getStatus())
                .build();
        return ResponseEntity.status(HttpStatus.CREATED).body(loadResponse);
    }

    @GetMapping
    @Operation(description = "Get all loads")
    @ApiResponse(responseCode = "200", description = "Loads retrieved successfully")
    public ResponseEntity<List<LoadResponse>> getAllLoads() {
        List<LoadEntity> loads = loadService.readAll();
        List<LoadResponse> loadResponses = loads.stream()
                .map(load -> LoadResponse.builder()
                        .id(load.getId())
                        .weight(load.getWeight())
                        .status(load.getStatus())
                        .build())
                .collect(Collectors.toList());
        return ResponseEntity.ok(loadResponses);
    }

    @GetMapping("/{id}")
    @Operation(description = "Get load by ID")
    @ApiResponse(responseCode = "200", description = "Load found successfully")
    @ApiResponse(responseCode = "404", description = "Load not found")
    public ResponseEntity<LoadResponse> getLoadById(@PathVariable Long id) {
        LoadEntity load = loadService.readById(id);
        if (load == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        LoadResponse loadResponse = LoadResponse.builder()
                .id(load.getId())
                .weight(load.getWeight())
                .status(load.getStatus())
                .build();
        return ResponseEntity.ok(loadResponse);
    }

    @PutMapping("/{id}")
    @Operation(description = "Update load by ID")
    @ApiResponse(responseCode = "200", description = "Load updated successfully")
    @ApiResponse(responseCode = "404", description = "Load not found")
    public ResponseEntity<LoadResponse> updateLoad(@PathVariable Long id, @RequestBody LoadRequest loadRequest) {
        LoadEntity updatedLoad = loadService.update(id, loadRequest);
        LoadResponse loadResponse = LoadResponse.builder()
                .id(updatedLoad.getId())
                .weight(updatedLoad.getWeight())
                .status(updatedLoad.getStatus())
                .build();
        return ResponseEntity.ok(loadResponse);
    }

    @DeleteMapping("/{id}")
    @Operation(description = "Delete load by ID")
    @ApiResponse(responseCode = "204", description = "Load deleted successfully")
    @ApiResponse(responseCode = "404", description = "Load not found")
    public ResponseEntity<Void> deleteLoad(@PathVariable Long id) {
        loadService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
