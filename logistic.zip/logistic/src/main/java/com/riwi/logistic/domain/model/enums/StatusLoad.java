package com.riwi.logistic.domain.model.enums;

public enum StatusLoad {
    PENDING,
    IN_TRANSIT,
    DELIVERED
}
