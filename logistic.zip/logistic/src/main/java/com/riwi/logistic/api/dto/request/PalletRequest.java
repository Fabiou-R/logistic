package com.riwi.logistic.api.dto.request;

import com.riwi.logistic.domain.model.LoadEntity;
import com.riwi.logistic.domain.model.enums.StatusPallets;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PalletRequest {
    private Long id;
    private Double weightMax;
    private Double heightMax;
    private String ubication;
    private LoadEntity load;
    private StatusPallets status;
}
