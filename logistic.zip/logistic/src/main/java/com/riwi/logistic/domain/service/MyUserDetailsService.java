package com.riwi.logistic.domain.service;

import com.riwi.logistic.api.dto.request.UserPrincipal;
import com.riwi.logistic.domain.model.UserEntity;
import com.riwi.logistic.domain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    private UserRepository userRepo;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserEntity user = userRepo.findByUsername(username);
        if (user == null) {
            System.out.printf("User not found: %s", username);
            throw new UsernameNotFoundException(username);
        }
        return new UserPrincipal(user);
    }
}