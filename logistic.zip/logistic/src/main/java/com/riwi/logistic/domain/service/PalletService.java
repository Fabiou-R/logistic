package com.riwi.logistic.domain.service;

import com.riwi.logistic.api.dto.request.PalletRequest;
import com.riwi.logistic.api.utils.TransformUtil;
import com.riwi.logistic.domain.model.PalletEntity;
import com.riwi.logistic.domain.repository.PalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PalletService {

    @Autowired
    private PalletRepository palletRepo;

    @Autowired
    private TransformUtil transformUtil;

    public PalletEntity create(PalletRequest palletRequest) {
        PalletEntity pallet = new PalletEntity();
        pallet.setUbication(palletRequest.getUbication());
        pallet.setLoad(palletRequest.getLoad());
        pallet.setStatus(palletRequest.getStatus());


        return palletRepo.save(pallet);
    }

    public List<PalletEntity> readAll() {
        return palletRepo.findAll();
    }

    public PalletEntity readById(Long id) {
        return palletRepo.findById(id).orElse(null);
    }

    public PalletEntity update(Long id, PalletRequest palletRequest) {
        PalletEntity pallet = readById(id);
        if (pallet != null) {
            pallet.setStatus(palletRequest.getStatus());
            pallet.setLoad(palletRequest.getLoad());
            pallet.setUbication(palletRequest.getUbication());
            return palletRepo.save(pallet);
        } else {
            throw new RuntimeException("Pallet no encontrado.");
        }
    }

    public void delete(Long id) {
        palletRepo.deleteById(id);
    }
}

