package com.riwi.logistic.api.dto.request;

import com.riwi.logistic.domain.model.enums.StatusLoad;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoadRequest {

    private Long id;
    private Double weight;
    private StatusLoad status;
}
