package com.riwi.logistic.domain.repository;

import com.riwi.logistic.domain.model.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserEntity,Long>  {
    UserEntity findByUsername(String username);

    boolean existsByUsername(String username);
}
