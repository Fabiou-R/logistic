package com.riwi.logistic.api.controllers;

import com.riwi.logistic.api.dto.request.PalletRequest;
import com.riwi.logistic.api.dto.response.PalletResponse;
import com.riwi.logistic.domain.model.PalletEntity;
import com.riwi.logistic.domain.service.PalletService;
import com.riwi.logistic.api.dto.response.LoadResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/pallets")
public class PalletController {

    private final PalletService palletService;

    @Autowired
    public PalletController(PalletService palletService) {
        this.palletService = palletService;
    }

    @PostMapping("/create")
    @Operation(description = "Create a new pallet")
    @ApiResponse(responseCode = "201", description = "Pallet created successfully")
    @ApiResponse(responseCode = "400", description = "Unable to create pallet")
    public ResponseEntity<PalletResponse> createPallet(@RequestBody PalletRequest palletRequest) {
        PalletEntity savedPallet = palletService.create(palletRequest);
        PalletResponse palletResponse = PalletResponse.builder()
                .weightMax(savedPallet.getWeightMax())
                .heightMax(savedPallet.getHeightMax())
                .ubication(savedPallet.getUbication())
                .load(LoadResponse.builder()
                        .id(savedPallet.getLoad().getId())
                        .weight(savedPallet.getLoad().getWeight())
                        .status(savedPallet.getLoad().getStatus())
                        .build())
                .status(savedPallet.getStatus())
                .build();
        return ResponseEntity.status(HttpStatus.CREATED).body(palletResponse);
    }

    @GetMapping("readAll")
    @Operation(description = "Get all pallets")
    @ApiResponse(responseCode = "200", description = "Pallets retrieved successfully")
    public ResponseEntity<List<PalletResponse>> getAllPallets() {
        List<PalletEntity> pallets = palletService.readAll();
        List<PalletResponse> palletResponses = pallets.stream()
                .map(pallet -> PalletResponse.builder()
                        .weightMax(pallet.getWeightMax())
                        .heightMax(pallet.getHeightMax())
                        .ubication(pallet.getUbication())
                        .load(LoadResponse.builder() // Cambiar aquí
                                .id(pallet.getLoad().getId())
                                .weight(pallet.getLoad().getWeight())
                                .status(pallet.getLoad().getStatus())
                                .build())
                        .status(pallet.getStatus())
                        .build())
                .collect(Collectors.toList());
        return ResponseEntity.ok(palletResponses);
    }

    @GetMapping("readById/{id}")
    @Operation(description = "Get pallet by ID")
    @ApiResponse(responseCode = "200", description = "Pallet found successfully")
    @ApiResponse(responseCode = "404", description = "Pallet not found")
    public ResponseEntity<PalletResponse> getPalletById(@PathVariable Long id) {
        PalletEntity pallet = palletService.readById(id);
        if (pallet == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        PalletResponse palletResponse = PalletResponse.builder()
                .weightMax(pallet.getWeightMax())
                .heightMax(pallet.getHeightMax())
                .ubication(pallet.getUbication())
                .load(LoadResponse.builder()
                        .id(pallet.getLoad().getId())
                        .weight(pallet.getLoad().getWeight())
                        .status(pallet.getLoad().getStatus())
                        .build())
                .status(pallet.getStatus())
                .build();
        return ResponseEntity.ok(palletResponse);
    }

    @PutMapping("update/{id}")
    @Operation(description = "Update pallet by ID")
    @ApiResponse(responseCode = "200", description = "Pallet updated successfully")
    @ApiResponse(responseCode = "404", description = "Pallet not found")
    public ResponseEntity<PalletResponse> updatePallet(@PathVariable Long id, @RequestBody PalletRequest palletRequest) {
        PalletEntity updatedPallet = palletService.update(id, palletRequest);
        PalletResponse palletResponse = PalletResponse.builder()
                .weightMax(updatedPallet.getWeightMax())
                .heightMax(updatedPallet.getHeightMax())
                .ubication(updatedPallet.getUbication())
                .load(LoadResponse.builder()
                        .id(updatedPallet.getLoad().getId())
                        .weight(updatedPallet.getLoad().getWeight())
                        .status(updatedPallet.getLoad().getStatus())
                        .build())
                .status(updatedPallet.getStatus())
                .build();
        return ResponseEntity.ok(palletResponse);
    }

    @DeleteMapping("delete/{id}")
    @Operation(description = "Delete pallet by ID")
    @ApiResponse(responseCode = "204", description = "Pallet deleted successfully")
    @ApiResponse(responseCode = "404", description = "Pallet not found")
    public ResponseEntity<Void> deletePallet(@PathVariable Long id) {
        palletService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
