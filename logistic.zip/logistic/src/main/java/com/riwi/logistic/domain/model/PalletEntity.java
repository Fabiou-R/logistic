package com.riwi.logistic.domain.model;

import com.riwi.logistic.domain.model.enums.StatusPallets;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "pallets")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class PalletEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double weightMax;

    private Double heightMax;

    private String ubication;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "load_id")
    private LoadEntity load;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusPallets status;
}
