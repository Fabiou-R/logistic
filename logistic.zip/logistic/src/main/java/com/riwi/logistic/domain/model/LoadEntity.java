package com.riwi.logistic.domain.model;

import com.riwi.logistic.domain.model.enums.StatusLoad;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@Table(name = "loads")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LoadEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double weight;

    private StatusLoad status;


}
