package com.riwi.logistic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogisticApplicationTests {

	@Test
	void contextLoads() {
	}

}
